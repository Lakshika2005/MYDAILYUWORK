let currentStep = 1;
const verificationCode = "1234";  // Simulated verification code

// Step 1 Validation
function validateStep1() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    
    let isValid = true;

    // Validate Name
    if (name === "") {
        document.getElementById("name-error").classList.remove("hidden");
        isValid = false;
    } else {
        document.getElementById("name-error").classList.add("hidden");
    }

    // Validate Email
    if (!validateEmail(email)) {
        document.getElementById("email-error").classList.remove("hidden");
        isValid = false;
    } else {
        document.getElementById("email-error").classList.add("hidden");
    }

    // Validate Password
    if (password === "") {
        document.getElementById("password-error").classList.remove("hidden");
        isValid = false;
    } else {
        document.getElementById("password-error").classList.add("hidden");
    }

    if (isValid) {
        nextStep(2);
    }
}

// Email validation regex
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}

// Step navigation and progress update
function nextStep(step) {
    document.getElementById(`step-${currentStep}`).classList.add('hidden');
    document.getElementById(`step-${step}`).classList.remove('hidden');
    currentStep = step;
    updateProgress(step);
}

function updateProgress(step) {
    const progress = document.getElementById('progress');
    progress.style.width = `${step * 33}%`;
}

// Step 3: Verification
function validateVerification() {
    const enteredCode = document.getElementById("verification-code").value;

    if (enteredCode === verificationCode) {
        document.getElementById("code-error").classList.add("hidden");
        completeSignup();
    } else {
        document.getElementById("code-error").classList.remove("hidden");
    }
}

function completeSignup() {
    document.getElementById(`step-${currentStep}`).classList.add('hidden');
    document.getElementById('complete-message').classList.remove('hidden');
    updateProgress(3);
}
