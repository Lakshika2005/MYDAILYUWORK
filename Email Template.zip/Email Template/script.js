document.getElementById("demoBtn").addEventListener("click", function(event) {
    event.preventDefault();
    window.open("https://www.example.com", "_blank");
    alert("You are about to experience something exciting!");
  });
  